Michael Rallo msr5zb 123458133
Please read the Documentation.pdf located in this folder.

Quick Program Details:
Keys: 1, 2, 3 loads in different Objects.
Keys: A, S, D changes display type.
KeyL I toggle the XYZ grid.
Array Keys adjusted/rotates view.