Michael Rallo msr5zb 123458133
Please read the Documentation.pdf located in this folder.

Quick Program Details:
Key: Esc exits the program.
Keys: 1, 2, 3 loads in different Objects.
Keys: a, s, d changes display type.
Key: i toggles the XYZ grid.
Keys: +, - Zooms In/Out.
Keys: m,n Scales Objects.
Key: p switches from Perspective to Orthographic (Default is Perspective).
Key: o enables Z-Axis Rotation for Orthographic View.
Array Keys adjusts/rotates object/view incrementally.
Click and Drag to Rotate Object, further you drag quicker it rotates.
